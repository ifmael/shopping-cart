export default interface IBeer {
  id: number;
  name: string;
  image_url: string;
}
