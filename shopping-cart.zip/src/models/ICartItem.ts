import IBeer from 'models/IBeer';

export default interface ICartItem {
  item: IBeer;
  count: number;
}
