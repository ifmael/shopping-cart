const API = 'https://api.punkapi.com/v2/beers';

export default API;
